# UART Transmitter & Receiver – SystemVerilog/UVM Testbench

This mini–project implements a simple UART (Universal Asynchronous Receiver/Transmitter)
datapath and a corresponding self‑checking UVM-style testbench in SystemVerilog.

## Features
- Configurable baud rate (via parameter)
- 8‑bit data, 1 start bit, 1 stop bit
- Separate TX and RX modules
- Self‑checking testbench: sends random bytes and checks received data
- Simple scoreboard and assertions for protocol checks

## Files
- `design.sv` – RTL for UART TX/RX
- `tb.sv` – SystemVerilog testbench (clock/reset generation, stimulus, checks)

## How to run (generic)
```tcl
vlog design.sv tb.sv
vsim -c work.tb -do "run -all; quit"
```

You can adapt the compile/run commands for any simulator (ModelSim, Questa, Xcelium, VCS, etc.).
